package com.tweetapp.userservice;

class UserServiceApplicationTest {

}
