package com.tweetapp.tweetservice.model;

public class ResponseDO {
	private String name;

	public ResponseDO() {
		// TODO Auto-generated constructor stub
	}
	public ResponseDO(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
