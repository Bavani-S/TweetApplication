package com.tweetapp.tweetservice;

class TweetServiceApplicationTest {

}
