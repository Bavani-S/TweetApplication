package com.tweetapp.authenticationservice;

class AuthenticationMsApplicationTests {

}
