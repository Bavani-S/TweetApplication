package com.tweetapp.authenticationservice.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.tweetapp.authenticationservice.model.AppUser;

@Repository
public class LoginRepository {

	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	
	public AppUser findByEmailId(String emailId) {
		List<AppUser> result = dynamoDBMapper.scan(AppUser.class, new DynamoDBScanExpression());
		List<AppUser> resultFilter = result.stream().filter(user -> user.getEmailId().contains(emailId)).collect(Collectors.toList());
		if(resultFilter.size() == 0) {
			return null;
		} else {
			return resultFilter.get(0);
		}
	}
	
	public List<AppUser> findAll() {
		List<AppUser> result = dynamoDBMapper.scan(AppUser.class, new DynamoDBScanExpression());
		return result;
	}
	
	public AppUser save(AppUser user) {
		dynamoDBMapper.save(user);
		return user;
	}

	public AppUser findByUserId(String userId) {
		 return dynamoDBMapper.load(AppUser.class, userId);
	}

	public void deleteByUserName(String userName) {
		 dynamoDBMapper.delete(dynamoDBMapper.load(AppUser.class, userName));
		System.out.println("deleted");
	}


}
