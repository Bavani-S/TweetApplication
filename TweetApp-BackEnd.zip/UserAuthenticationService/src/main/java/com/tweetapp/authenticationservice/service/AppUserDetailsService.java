package com.tweetapp.authenticationservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.tweetapp.authenticationservice.model.AppUser;
import com.tweetapp.authenticationservice.repository.LoginRepository;

@Service
public class AppUserDetailsService implements UserDetailsService {

	// Class to Implement UserDetailsService in Spring security

	@Autowired
	private LoginRepository loginRepo;

	@Override
	public UserDetails loadUserByUsername(String userid) throws UsernameNotFoundException {

		AppUser user =null;
		user= loginRepo.findByUserId(userid); //findByUserName(userid);

		//User userDetail=null;
		if (user != null) {
			if(user.getUserName()!=null &&  user.getPassword()!=null && user.getRole()!=null) {
			List<GrantedAuthority> grantedAuthorities = AuthorityUtils
					.commaSeparatedStringToAuthorityList("ROLE_" + user.getRole());
			return new User(user.getUserName(), user.getPassword(), grantedAuthorities);
			}else 
				System.out.println("Username/Password is Invalid/Null ...Please Check");
		} else {
			throw new UsernameNotFoundException("Username/Password is Invalid...Please Check");
		}
		return null;
	}

	private AppUser findByUserName(String userName) {
		List<AppUser> appUserList= loginRepo.findAll();
		System.out.println("load user by name\n"+appUserList.toString());
		AppUser appuser = null;
		appUserList.forEach(appUser->System.out.println(appUser.toString()));
		for(AppUser user : appUserList) {
			if(user.getUserName()!=null) {
			if(user.getUserName().equalsIgnoreCase(userName)) {
				appuser=user;
				break;
			}}
		}
		if(appuser==null)
			System.out.println("appuser value null");
		else
			System.out.println(appuser.toString());
		return appuser;
	}
	public void deleteUser(String id) {
		loginRepo.deleteByUserName(id);
	}

}
