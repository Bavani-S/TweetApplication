package com.tweetapp.authenticationservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tweetapp.authenticationservice.model.AuthenticationResponse;
import com.tweetapp.authenticationservice.repository.LoginRepository;

@Component
public class Validationservice {

	@Autowired
	private JwtUtil jwtutil;
	@Autowired
	private LoginRepository userRepo;

	public AuthenticationResponse validate(String token) {
		AuthenticationResponse authenticationResponse = new AuthenticationResponse();

		String jwt = token.substring(7);

		if (jwtutil.validateToken(jwt)) {
			authenticationResponse.setUserid(jwtutil.extractUsername(jwt));
			authenticationResponse.setValid(true);
			authenticationResponse.setName(userRepo.findByUserId(jwtutil.extractUsername(jwt)).getUserName());
		} else {
			authenticationResponse.setValid(false);
		}
		return authenticationResponse;
	}
}