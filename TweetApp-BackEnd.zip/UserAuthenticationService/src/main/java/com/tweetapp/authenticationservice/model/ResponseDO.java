package com.tweetapp.authenticationservice.model;

public class ResponseDO {
	private String name;

	public ResponseDO(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
