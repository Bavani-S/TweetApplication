package com.tweetapp.authenticationservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.tweetapp.authenticationservice.exceptionhandling.AppUserNotFoundException;
import com.tweetapp.authenticationservice.model.AppUser;
import com.tweetapp.authenticationservice.model.ErrorMessage;
import com.tweetapp.authenticationservice.model.LoginRequestDTO;
import com.tweetapp.authenticationservice.model.LoginResponseDTO;
import com.tweetapp.authenticationservice.model.PasswordGenerationHash;
import com.tweetapp.authenticationservice.model.RegisterResponseDTO;
import com.tweetapp.authenticationservice.repository.LoginRepository;

import lombok.extern.slf4j.Slf4j;


@Component
@Slf4j
public class LoginService {

	@Autowired
	private JwtUtil jwtutil;
	@Autowired
	private LoginRepository loginRepo;
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	@Autowired
	private AppUserDetailsService appuserDetailservice;

	public LoginResponseDTO userLogin(LoginRequestDTO loginRequest) throws AppUserNotFoundException {
	   AppUser appuser = loginRepo.findByUserId(loginRequest.getUserName());
	   if(appuser==null) {
		   return new LoginResponseDTO(null,null,new ErrorMessage(500,"User doesn't exist"),null);
	   }
	   String emailId= appuser.getEmailId();
		final UserDetails userdetails = appuserDetailservice.loadUserByUsername(loginRequest.getUserName());
		String userid = "";
		String role="";
		String token = "";
		
		log.info("Password From DB-->{}" ,userdetails.getPassword());
		log.info("Password From Request-->{}", encoder.encode(loginRequest.getPassword()) );

		if (userdetails.getPassword().equalsIgnoreCase(loginRequest.getPassword()) ) {
			userid = loginRequest.getUserName();
			token = jwtutil.generateToken(userdetails);
			return new LoginResponseDTO(userid,emailId,null,token);
		} else {
			return new LoginResponseDTO(null,null,new ErrorMessage(500,"Invalid credential"),null);
		}
	}
	
	private AppUser findByUserName(String userName) {
		List<AppUser> appUserList= loginRepo.findAll();
		System.out.println(appUserList.toString());
		AppUser appuser = null;
		//appUserList.forEach(appUser->System.out.println(appUser.toString()));
		for(AppUser user : appUserList) {
			if(user.getUserName()!=null) {
			if(user.getUserName().equalsIgnoreCase(userName)) {
				appuser=user;
				return user;
			}}
		}
		if(appuser==null)
			System.out.println("appuser value null");
		else
			System.out.println(appuser.toString());
		return appuser;
	}

	public RegisterResponseDTO forgotPassword(String userId, String password) throws Exception {
		RegisterResponseDTO forgot = new RegisterResponseDTO();
		Boolean status = true;
		try {
			AppUser register = findByUserName(userId);
			if (register != null) {
				String saltValue = PasswordGenerationHash.getSalt();
				register.setPassword(PasswordGenerationHash.get_SHA_384_SecurePassword(password, saltValue));
				loginRepo.deleteByUserName(userId);
				loginRepo.save(register);
				forgot.setErrorMessage(null);
			} else {
				status = false;
				forgot.setErrorMessage(new ErrorMessage(104, "No User Id found"));
			}
		} catch (Exception e) {
			status = false;
			throw new Exception();
		}
		forgot.setStatus(status);
		return forgot;
	}

	public RegisterResponseDTO forgotPassword(String userId, String password, String dob) {
		RegisterResponseDTO forgot = new RegisterResponseDTO();
		Boolean status = true;
		AppUser register = findByUserName(userId);
		if(register!=null) {
			if(register.getEmailId().equalsIgnoreCase(dob)) {
				register.setPassword(password);
				loginRepo.deleteByUserName(userId);
				loginRepo.save(register);
				forgot.setErrorMessage(null);
			}else {
				status=false;
				forgot.setErrorMessage(new ErrorMessage(104, "No User Id found"));
			}
		}
		forgot.setStatus(status);
		return forgot;
	}
}